module.exports = {
    outbreak: true
}